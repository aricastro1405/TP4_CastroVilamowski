﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TP4_Castro_Vilamowski.Models;

namespace TP4_Castro_Vilamowski.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        ViewBag.IndumentariasEquipos=Equipos.EquiposIndumentaria;
        return View("Index");
    }
    public IActionResult SelectIndumentaria(){
        ViewBag.MediasLista=Equipos.ListaMedias;
        ViewBag.PantalonesLista=Equipos.ListaPantalones;
        ViewBag.RemerasLista=Equipos.ListaRemeras;
        if(ViewBag.MediasLista>10||ViewBag.MediasLista<0){
            ViewBag.MensajeError="No existe esa opción!";
            return View (ViewBag.MensajeError);
        }
        else {
            return View ("Index");
        }
        return View("SelectIndumentaria");
    }
    public IActionResult GuardarIndumentaria (int Equipo, int Media, int Pantalon, int Remera){
        string media=" ",pantalon=" ",remera=" "; 
        Indumentaria item=new Indumentaria(Equipos.ListaMedias[Media],Equipos.ListaPantalones[Pantalon],Equipos.ListaRemeras[Remera]);
        string EquipoSeleccionado=Equipos.ListaEquipos[Equipo];
        bool sepuede=Equipos.IngresarIndumentaria(EquipoSeleccionado,item);
        return View();
    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
